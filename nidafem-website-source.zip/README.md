# Nidafem Services & Logistics Nig. Ltd. website

A responsive, mobile-first corporate enquiry website built with HTML, CSS, vanilla JavaScript and a Cloudflare Pages Function.

## Project structure

```text
nidafem-website/
├── index.html
├── styles.css
├── script.js
├── privacy.html
├── 404.html
├── _headers
├── wrangler.toml
├── functions/
│   └── api/
│       └── quote.js
└── assets/
    ├── favicon.svg
    └── og-placeholder.svg
```

## Important launch status

This is a source project, not a deployed website. The enquiry form intentionally shows an error until server-side email settings are configured and tested. Do not advertise the form as operational before completing the steps below.

The supplied logo/letterhead was not included as an actual file in this project, so the header currently uses a simple temporary “N” mark. Replace it with the approved company logo before launch. The hero and print visuals are CSS illustrations; print samples are labelled as illustrative mockups and are not claimed as completed company projects.

## Run locally

You can preview the static layout by opening `index.html`, but the form will not work through a simple file preview. To test the Pages Function locally, use Node.js and Wrangler:

```bash
npm install -g wrangler
wrangler pages dev .
```

Open the local URL Wrangler prints. Cloudflare Pages Functions are in the `functions/` directory.

## Configure real email delivery

This project uses Resend's email API from a server-side Cloudflare Pages Function. No API key is placed in browser JavaScript.

1. Create/verify a Resend account and verify a sender domain. Use a sender address permitted by your provider; do not assume a Gmail address can be used as the sending identity.
2. In Cloudflare Dashboard, open **Workers & Pages** and create a Pages project from this repository, or upload/connect the project.
3. In the Pages project, open **Settings → Variables and Secrets** (wording may vary) and add these as encrypted secrets/environment variables:
   - `RESEND_API_KEY` — your private Resend API key
   - `QUOTE_TO_EMAIL` — the company inbox that should receive enquiries
   - `QUOTE_FROM_EMAIL` — a verified sender identity on your verified domain
4. Set the variables for both Preview and Production as appropriate. Never put the API key in `script.js`, HTML, GitHub commits or public environment variables.
5. Redeploy after configuring the variables.
6. Submit a test enquiry using an inbox and phone number you control. Confirm the email arrives, reply-to works, validation errors are useful, and failed delivery does not show success.
7. Check your provider logs and Cloudflare function logs without exposing enquiry contents unnecessarily.

### Local environment

For local Wrangler testing, create a `.dev.vars` file in the project root (do not commit it):

```dotenv
RESEND_API_KEY=replace-with-your-private-key
QUOTE_TO_EMAIL=nidafemserviceslogistics@gmail.com
QUOTE_FROM_EMAIL=Website Enquiries <enquiries@your-verified-domain.example>
```

Replace the example sender with a verified address on a domain you control. Add `.dev.vars` to `.gitignore` before committing. If using Git, do not commit real credentials.

## Deploy to Cloudflare Pages

### Option A — Git integration (recommended)

1. Put the project files in a GitHub repository.
2. In Cloudflare Dashboard, go to **Workers & Pages → Create → Pages → Connect to Git**.
3. Select the repository.
4. For this static project, leave the build command empty if the dashboard allows it and set the output directory to `/` or `.` according to the dashboard's current validation. If Cloudflare requires a build output directory, use a small build step that copies the site files to a dedicated `dist/` folder and set output to `dist`.
5. Deploy, then configure the three email environment variables/secrets.
6. Redeploy and test `/api/quote`.

### Option B — Wrangler CLI

Install Node.js, then:

```bash
npm install -g wrangler
wrangler login
wrangler pages project create nidafem-website
wrangler pages deploy . --project-name nidafem-website
```

Check the current Wrangler prompts and Cloudflare Pages documentation because CLI syntax can change. Do not deploy from a directory that contains local secrets.

## Connect a custom domain

1. Register or use a domain the company owns.
2. In Cloudflare Dashboard, open the Pages project → **Custom domains** → **Set up a custom domain**.
3. Follow Cloudflare's instructions. If the domain is managed elsewhere, update the required DNS records at the registrar. If Cloudflare asks you to add the domain to its DNS first, follow that guided process.
4. Wait for DNS and certificate provisioning, then test the HTTPS version on desktop and mobile.
5. Choose the preferred canonical hostname (for example, `www` or apex) and configure redirects if required.

Do not publish until the company confirms domain ownership and access.

## Form behaviour and security notes

- Form posts JSON to `/api/quote`.
- The Cloudflare Pages Function validates required fields, enforces field length limits and checks consent.
- A honeypot catches simple bots. For stronger protection at launch, configure Cloudflare Turnstile and verify its token server-side, or use a managed rate-limiting rule. A honeypot alone is not comprehensive spam protection.
- Enquiries are emailed using the server-side Resend API. A success message is shown only after the provider accepts the email request.
- A provider accepting an email request is not a guarantee of final inbox delivery; monitor delivery/bounce logs.
- This draft does not store enquiries in a database.
- Add a clear retention process and restrict access to the recipient inbox.
- Privacy policy is a draft and should be reviewed against the company's actual practices and applicable Nigerian data-protection requirements.

## SEO and analytics

- Title, description, Open Graph tags and organization structured data are included.
- Review the canonical URL, social sharing image and favicon once the domain/logo are final.
- The analytics hook is inert by default. If adding analytics or ad pixels, configure the relevant accounts, consent and privacy disclosures first.
- Structured data contains only the supplied company details; verify addresses, phone numbers and legal name before launch.

## Pre-launch checklist

- [ ] Replace temporary “N” brand mark with the approved logo and supplied letterhead assets.
- [ ] Confirm company name spelling and RC number.
- [ ] Verify all phone numbers, email and each office address with the company.
- [ ] Confirm which number, if any, is the official WhatsApp line before adding a WhatsApp CTA.
- [ ] Confirm service descriptions, capabilities and any import/export/clearing scope.
- [ ] Configure and test email provider secrets.
- [ ] Test valid submission, missing fields, invalid email, spam honeypot and backend failure.
- [ ] Configure Turnstile or another appropriate anti-spam/rate-limit measure.
- [ ] Review and approve the privacy policy and retention process.
- [ ] Check navigation, anchor links, phone/email links and all quote CTAs.
- [ ] Test on small mobile, tablet and desktop viewports.
- [ ] Check keyboard navigation, visible focus, colour contrast and screen-reader labels.
- [ ] Compress and replace placeholder/social images as needed.
- [ ] Test HTTPS, 404 page, page metadata and custom-domain redirects.
- [ ] Check form logs and provider delivery/bounce reports after launch.
- [ ] Only add verified testimonials, client logos, certifications, photos and performance claims.

## Company confirmations still required

1. Approved logo file and any original letterhead brand assets.
2. Correct spelling/formatting of all three office addresses and whether visitors should attend without appointment.
3. Which number should receive WhatsApp messages.
4. Confirmed service scope, operating areas, relevant licences/authorisations and any limitations.
5. The destination inbox for quote requests and approved sending domain.
6. Final privacy policy owner/contact, retention period and approval.
7. Whether a public business address and all telephone numbers should appear on the website.
