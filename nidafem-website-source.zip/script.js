(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#primary-nav');
  menuButton?.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    menuButton.textContent = open ? '×' : '☰';
  });
  nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton?.setAttribute('aria-expanded', 'false');
    if (menuButton) { menuButton.textContent = '☰'; menuButton.setAttribute('aria-label', 'Open navigation'); }
  }));
  document.querySelector('#year').textContent = new Date().getFullYear();

  document.querySelectorAll('.quote-link, [data-prefill]').forEach(link => {
    link.addEventListener('click', () => {
      const service = link.dataset.service || link.dataset.prefill;
      if (service) {
        const select = document.querySelector('[name="service"]');
        if (select) select.value = service;
      }
    });
  });

  const form = document.querySelector('#quote-form');
  const status = document.querySelector('#form-status');
  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    status.textContent = '';
    status.className = 'form-status';
    if (!form.reportValidity()) return;
    const submit = form.querySelector('button[type="submit"]');
    submit.disabled = true;
    submit.textContent = 'Submitting…';
    try {
      const payload = Object.fromEntries(new FormData(form).entries());
      payload.consent = form.querySelector('[name="consent"]').checked;
      const response = await fetch('/api/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || !result.ok) throw new Error(result.error || 'We could not submit your enquiry. Please try again or contact us by phone or email.');
      status.textContent = 'Thank you. Your enquiry has been submitted successfully. The team can now review your request.';
      status.classList.add('success');
      form.reset();
      document.dispatchEvent(new CustomEvent('nlt:quote-submitted', { detail: { service: payload.service } }));
    } catch (error) {
      status.textContent = error.message || 'Something went wrong. Please try again.';
      status.classList.add('error');
    } finally {
      submit.disabled = false;
      submit.innerHTML = 'Submit Enquiry <span aria-hidden="true">→</span>';
    }
  });

  // Optional analytics hook. Attach your approved analytics provider before using it.
  document.addEventListener('click', (event) => {
    const anchor = event.target.closest('a');
    if (!anchor) return;
    let eventName = '';
    if (anchor.matches('.button, .quote-link, [href="#quote"]')) eventName = 'request_quote_click';
    else if (anchor.href.startsWith('tel:')) eventName = 'phone_click';
    else if (anchor.href.startsWith('mailto:')) eventName = 'email_click';
    else if (anchor.href.includes('wa.me')) eventName = 'whatsapp_click';
    if (eventName && window.nidafemTrack) window.nidafemTrack(eventName, { href: anchor.getAttribute('href') });
  });
})();