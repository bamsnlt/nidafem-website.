const ALLOWED_SERVICES = new Set([
  "Printing and Packaging",
  "Branding and Large-Format Printing",
  "Procurement and Office Supplies",
  "Logistics, Import and Export",
  "Warehousing and Storage",
  "General Contracting",
  "Other / Not sure"
]);
const clean = (value, max = 3000) => String(value ?? "").trim().slice(0, max);
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function onRequestPost({ request, env }) {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  };
  const reply = (status, body) => new Response(JSON.stringify(body), { status, headers });
  if (!env.RESEND_API_KEY || !env.QUOTE_TO_EMAIL || !env.QUOTE_FROM_EMAIL) {
    return reply(503, { ok: false, error: "The enquiry form is not configured yet. Please contact Nidafem by phone or email." });
  }
  const contentType = request.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) return reply(415, { ok: false, error: "Unsupported submission format." });

  let data;
  try { data = await request.json(); } catch { return reply(400, { ok: false, error: "Please check your form details and try again." }); }
  // Honeypot: quietly accept bots without sending an email.
  if (clean(data.website, 200)) return reply(200, { ok: true });

  const name = clean(data.name, 100);
  const phone = clean(data.phone, 30);
  const company = clean(data.company, 120);
  const email = clean(data.email, 160);
  const service = clean(data.service, 100);
  const details = clean(data.details, 3000);
  const contactMethod = clean(data.contact_method, 50);
  const location = clean(data.location, 200);
  const quantity = clean(data.quantity, 160);
  const timeframe = clean(data.timeframe, 160);
  const budget = clean(data.budget, 100);
  const nextStep = clean(data.next_step, 80);

  if (name.length < 2 || phone.length < 7 || !ALLOWED_SERVICES.has(service) || details.length < 10 ||
      !["Phone call", "WhatsApp (only if available on the contact number)", "Email"].includes(contactMethod) ||
      data.consent !== true) {
    return reply(400, { ok: false, error: "Please complete all required fields and accept the privacy notice." });
  }
  if (email && !emailPattern.test(email)) return reply(400, { ok: false, error: "Please enter a valid email address." });
  if (/[<>]/.test(name) || /[\r\n]/.test(email)) return reply(400, { ok: false, error: "Please check the format of your details." });

  const text = [
    "New Nidafem website enquiry",
    "",
    `Name: ${name}`,
    `Phone: ${phone}`,
    `Company: ${company || "Not provided"}`,
    `Email: ${email || "Not provided"}`,
    `Service: ${service}`,
    `Preferred contact method: ${contactMethod}`,
    `Location: ${location || "Not provided"}`,
    `Quantity / project size: ${quantity || "Not provided"}`,
    `Required timeframe: ${timeframe || "Not provided"}`,
    `Budget range: ${budget || "Not provided"}`,
    `Requested next step: ${nextStep || "Not specified"}`,
    "",
    "Requirement details:",
    details,
    "",
    "Submitted through the Nidafem website enquiry form."
  ].join("\n");

  const message = {
    from: env.QUOTE_FROM_EMAIL,
    to: [env.QUOTE_TO_EMAIL],
    subject: `[Website Enquiry] ${service} — ${name}`,
    text
  };
  if (email) message.reply_to = email;

  try {
    const providerResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(message)
    });
    if (!providerResponse.ok) {
      // Do not return provider details or secrets to the visitor.
      return reply(502, { ok: false, error: "We could not deliver your enquiry right now. Please try again later or contact us by phone or email." });
    }
    return reply(200, { ok: true });
  } catch {
    return reply(502, { ok: false, error: "We could not deliver your enquiry right now. Please try again later or contact us by phone or email." });
  }
}

export async function onRequest({ request }) {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: { "Allow": "POST, OPTIONS" } });
  }
  return new Response(JSON.stringify({ ok: false, error: "Method not allowed." }), {
    status: 405,
    headers: { "Content-Type": "application/json", "Allow": "POST" }
  });
}